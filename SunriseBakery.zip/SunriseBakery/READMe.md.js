# Sunrise Bakery Website

A responsive website for a family-owned bakery in Bloemfontein.

## Live Demo
https://your-username.github.io/sunrise-bakery/

## Features
- Responsive design
- Product gallery
- About section
- Contact form
- Custom order info

## Pages
- Home (index.html)
- Products (products.html) 
- Gallery (gallery.html)
- Our Work (our-work.html)
- About (about.html)
- Contact (contact.html)

## Technologies
- HTML5
- CSS3
- JavaScript

## Project Structure

